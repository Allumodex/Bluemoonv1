---------

### ❖  ＪＩＮＨＵＹＫ- ＭＤ - Ｖ２ ❖

🔰 **`A WhatsApp Multi Device Bot To Take Your WhatsApp To Another Level !`** 🔰

----------
## CLICK <a href="https://github.com/KangJinhuyk/JINHUYK-MD-V2/issues/2#issue-2744137419">HERE IF YOU ARE NEW TO BOTS</a>

<img src='https://i.postimg.cc/T1M4kVyf/JINHUYK-BOT2.jpg'/>

-------

 <p align="center">
  <a href="#"><img src="http://readme-typing-svg.herokuapp.com?color=cyan&center=true&vCenter=true&multiline=false&lines=`ＪＩＮＨＵＹＫ-MD+Ｖ２+W.A+BOT+BY+KANG+JINHUYK`" alt="">

<br>

--------

<p align="center">
<a href="https://github.com/KangJinhuyk/"><img title="Followers" src="https://img.shields.io/github/followers/KangJinhuyk?color=blue&style=flat-square"></a>
<a href="https://github.com/KangJinhuyk/JINHUYK-MD-V2/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/KangJinhuyk/JINHUYK-MD-V2?color=blue&style=flat-square"></a>
<a href="https://github.com/KangJinhuyk/JINHUYK-MD-V2/network/members"><img title="Forks" src="https://img.shields.io/github/forks/KangJinhuyk/JINHUYK-MD-V2?color=blue&style=flat-square"></a>
<a href="https://github.com/KangJinhuyk/JINHUYK-MD-V2/"><img title="Size" src="https://img.shields.io/github/repo-size/KangJinhuyk/JINHUYK-MD-V2?style=flat-square&color=blue"></a>
<a href="https://github.com/KangJinhuyk/JINHUYK-MD-V2/graphs/commit-activity"><img height="20" src="https://img.shields.io/badge/Maintained%3F-yes-green.svg"></a>&nbsp;&nbsp;
</p>
<p align='center'>
</p>

-----------
<div align="center"><br> <img src="https://profile-counter.glitch.me/JINHUYK-MD-V2/count.svg" /><br>JINHUYK-MD-V2</div>

------------

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

### <br>   ❖ DEPLOY_WORKFLOWS ❖
```
name: Node.js CI

on:
  push:
    branches:
      - main
  pull_request:
    branches:
      - main

jobs:
  build:

    runs-on: ubuntu-latest

    strategy:
      matrix:
        node-version: [20.x]

    steps:
    - name: Checkout repository
      uses: actions/checkout@v3

    - name: Set up Node.js
      uses: actions/setup-node@v3
      with:
        node-version: ${{ matrix.node-version }}

    - name: Install dependencies
      run: npm install

    - name: Start application
      run: npm start
```

[![FORK JINHUYK-MD-V2](https://img.shields.io/badge/FORK%20-JINHUYK%20MD%20V2-white)](https://github.com/KangJinhuyk/JINHUYK-MD-V2/fork)

### <br>    ❖ SESSION_ID ❖


`🚀 IF YOU DON'T HAVE YOUR SESSION_ID SO U CAN GET IT CLICK ON SESSION_ID BUTTON AND PASTE YOUR NUMBER With COUNTRY CODE EXAMPLE:+242xxxxxx THEN YOU CAN GET YOUR SESSION_ID 🚀`

----------
## SESSION JINHUYK-MD-V2
<p align="center">
<a href="https://sasaki-session-bot.onrender.com"><img height= "35" title="Author" src="https://img.shields.io/badge/GET SESSION ID:-black?style=for-the-badge&logo=render"></a>
<p/>
--------


 
🥂 `THIS BOT IS CREATED TO DOWNLOAD'S AND FIND VARIOUS TYPES THINGS QUICKLY **EXAMPLE** LOGO, PHOTO, STICKERS, VIDEOS, MOVIES, ADULT, AND MANY MORE FEATURES BY USING THIS BOT™ THIS BOT IS CREATED TO USING` 🥂 **[Baileys](https://github.com/WhiskeySockets/Baileys)**

------------------

### <br> ❖ FOR SUPPORT ❖

**`➩ HII DEARS FRIENDS IF YOU WANT ANY HELP SO YOU CAN CONTACT↘︎ WITH ME WIA WHATSAPP ITS ME MR FRANK ࿐➺`**

-------

<p align="center">
  <a href="https://wa.me/+242067274660?text=*ʜɪɪ+𝙺𝙰𝙽𝙶 𝙹𝙸𝙽𝙷𝚄𝚈𝙺+ɪ+ɴᴇᴇᴅ+ʜᴇʟᴘ!.+ʀᴇᴘᴏ!!*" target="_blank">
    <img alt="whatsapp" src="https://img.shields.io/badge/ Whatsapp -25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />

-----------    

`🚀 IF YOU WANT MORE ABOUT JINHUYK-MD-V2 WHATSAPP BOT :-NEW UPDATED NEW CMDS SO JOIN OUR WHATSAPP CHANNEL FOR MORE INFORMATION CLICK THIS RED BUTTON 🔳 AND JOIN THE GROUP 🚀`

---------

<a href="https://whatsapp.com/channel/0029Vajrhmz96H4IsEjh4a41"><img src="https://img.shields.io/badge/%F0%9F%8E%89%20ᴊᴏɪɴ%20ᴏᴜʀ%20ᴡʜᴀᴛsᴀᴘᴘ%20ᴄʜᴀɴɴᴇʟ-red" alt="🔰 ᴊᴏɪɴ ᴍʏ ᴡʜᴀᴛsᴀᴘᴘ ᴄʜᴀɴɴᴇʟ ғᴏʀ ᴜᴘᴅᴀᴛᴇ 🔰" width="300"></a>

-----------

`🚀 IF YOU WANT MORE ABOUT JINHUYK-MD-V2 WHATSAPP BOT :-NEW UPDATED NEW CMDS SO SUBSCRIBE OUR YOUTUBE CHANNEL FOR MORE INFORMATION CLICK THIS BLUE BUTTON 🔳 AND JOIN THE YOUTUBE CHANNEL 🚀`

----------

<a href="https://www.youtube.com/@SASAKICOMPAGNIE"><img src="https://img.shields.io/badge/%F0%9F%8E%89%20ᴊᴏɪɴ%20ᴏᴜʀ%20ʏᴏᴜᴛᴜʙᴇ%20ᴄʜᴀɴɴᴇʟ-blue" alt="🔰 ᴊᴏɪɴ ᴍʏ ʏᴏᴜᴛᴜʙᴇ ғᴏʀ ᴜᴘᴅᴀᴛᴇ 🔰" width="300"></a>

--------------
 
### <br>   ❖ DEPLOY_HEROKU ❖

`🚀 IF YOU WANT TO DEPLOY JINHUYK-MD-V2 BOT ON HEROKU SO FIRST GET YOUR SESSION_ID THEN CLICK THIS BLUE BUTTON [DEPLOY TO HEROKU] THEN YOU CAN ENJOY THIS BOT 🚀`

------------
 
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://dashboard.heroku.com/new-app?template=https://github.com/KangJinhuyk/JINHUYK-MD-V2)

----------

### <br>    ❖ DEPLOY_REPLIT ❖

`🚀 IF U HAVE YOUR REPLIT ACCOUNT SO YOU CAN EASY DEPLOY JINHUYK-MD-V2 ON REPLIT CLICK BLACK BUTTON [DEPLOY TO REPLIT] AND FIND CONFIG.JSON FILE THEN PASTE YOUR SESSION AND MONGODB KEY THEN RUN CODE AND ENJOY BOT 🚀`

-------------

<p align="left"><a href="https://repl.it/github/KangJinhuyk/JINHUYK-MD-V2"> <img src='https://img.shields.io/badge/-REPLIT-orange?style=for-the-badge&logo=replit&logoColor=white'/></a>

--------------

### <br>   ❖ DEPLOY_KOYEB ❖

`🚀 IF YOU HAVE YOUR KOYEB ACCOUNT SO YOU CAN DEPLOY JINHUYK-MD-V2  ON KOYEB WITH EASY SETUP NOTE:-MAYBE SOME PROBLEM TO DEPLOY ON KOYEB I ILL FIX SOON 🚀`

---------

<a href='https://app.koyeb.com/auth/signin' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/-KOYEB-blue?style=for-the-badge&logo=koyeb&logoColor=white'/></a>

------------

### <br>  ❖ DEPLOY_RAILWAY ❖

`🚀 IF YOU HAVE YOUR RAILWAY ACCOUNT SO YOU CAN DEPLOY JINHUYK-MD-V2  ON RAILWAY WITH EASY SETUP NOTE:-MAYBE SOME PROBLEM TO DEPLOY ON KOYEB I ILL FIX SOON 🚀`

--------

<a href='https://railway.app/new' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/RAILWAY-h?color=black&style=for-the-badge&logo=railway'/></a></p>

---------------

### <br> ❖ MORE DEPLOY METHOD ❖

--------
### <br>   ❖ DEPLOY_GLITCH ❖

<a href='https://glitch.com/signup' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/GLITCH-h?color=pink&style=for-the-badge&logo=glitch'/></a></p>

--------

### <br>   ❖ DEPLOY_CODESPACE ❖

<a href='https://github.com/codespaces/new' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/CODESPACE-h?color=navy&style=for-the-badge&logo=visualstudiocode'/></a></p>

--------

### <br>   ❖ DEPLOY_RENDER ❖

<a href='https://dashboard.render.com' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/RENDER-h?color=maroon&style=for-the-badge&logo=render'/></a></p>

-----------
`🚀 HOW TO DEPLOY JINHUYK-MD-V2  ON WORKFLOWS FREE GITHUB WATCH VIDEO 🚀`

-------------

<p align="center">
   <a href="https://www.youtube.com/@SASAKICOMPAGNIE"><img src="https://i.ibb.co/71mYRh4/116-1161192-podcast-subscribe-listen-button-youtube-sign-hd-png.png" alt="Watch tutorial on YouTube" border="0"  width="105">
    </a>
</p>

-------------

Thanks For Using JINHUYK-MD-V2 

> Release Date : 15/12/2024 at 00.00
Dᴏɴ’ᴛ Fᴏʀɢᴇᴛ ᴛᴏ ɢɪᴠᴇ ᴀ sᴛᴀʀ ⭐️ ᴀꜰᴛᴇʀ ꜰᴏʀᴋ
